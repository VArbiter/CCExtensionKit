//
//  CCAppDelegate.m
//  MQExtensionKit
//
//  Created by ElwinFrederick on 2018/7/30.
//  Copyright © 2018 ElwinFrederick. All rights reserved.
//

#import "CCAppDelegate.h"

@interface CCAppDelegate ()

@end

@implementation CCAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}


@end
