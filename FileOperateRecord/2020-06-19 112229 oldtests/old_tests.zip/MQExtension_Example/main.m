//
//  main.m
//  MQExtensionKit
//
//  Created by ElwinFrederick on 2018/7/30.
//  Copyright © 2018 ElwinFrederick. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CCAppDelegate class]));
    }
}
