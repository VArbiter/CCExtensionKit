//
//  ViewController.m
//  MQExtensionKit
//
//  Created by ElwinFrederick on 2018/7/30.
//  Copyright © 2018 ElwinFrederick. All rights reserved.
//

#import "ViewController.h"

#import "MQCommon.h"
#import "MQFit.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    void (^t)(void) = ^{NSLog(@"complete");};
    MQ_SAFE_BLOCK(t, t());
    
    NSLog(@"%d", mq_fit_is_has_bangs());
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
